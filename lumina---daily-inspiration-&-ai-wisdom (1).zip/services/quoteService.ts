import { QUOTES } from '../constants';
import { Quote } from '../types';

export const getDailyQuote = (): Quote => {
  // Use the current date to seed the random selection so it stays the same for 24 hours
  const today = new Date();
  const seed = today.getFullYear() * 10000 + (today.getMonth() + 1) * 100 + today.getDate();
  
  // Simple pseudo-random using the date seed
  const index = seed % QUOTES.length;
  return QUOTES[index];
};

export const getRandomQuote = (): Quote => {
  const index = Math.floor(Math.random() * QUOTES.length);
  return QUOTES[index];
};