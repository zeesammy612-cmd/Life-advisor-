import { GoogleGenAI, Chat, GenerateContentResponse } from "@google/genai";

const apiKey = process.env.API_KEY || '';

// Initialize client once
const ai = new GoogleGenAI({ apiKey });

export const createChatSession = (): Chat => {
  return ai.chats.create({
    model: 'gemini-3-pro-preview',
    config: {
      systemInstruction: "You are Lumina, a wise, empathetic, and uplifting AI companion. Your goal is to provide daily motivation, emotional support, and philosophical insights. Keep your responses concise, warm, and human-like. Avoid overly robotic or clinical language. When appropriate, offer a short inspiring quote or a practical mindfulness tip.",
    },
  });
};

export const sendMessageStream = async (
  chat: Chat, 
  message: string, 
  onChunk: (text: string) => void
): Promise<void> => {
  try {
    const resultStream = await chat.sendMessageStream({ message });
    
    for await (const chunk of resultStream) {
      const c = chunk as GenerateContentResponse;
      if (c.text) {
        onChunk(c.text);
      }
    }
  } catch (error) {
    console.error("Error sending message to Gemini:", error);
    onChunk("\n[I'm having trouble connecting to my inspiration source right now. Please try again in a moment.]");
  }
};