import React, { useState } from 'react';
import { HashRouter as Router, Routes, Route, Navigate, useLocation, useNavigate } from 'react-router-dom';
import QuoteScreen from './components/QuoteScreen';
import ChatScreen from './components/ChatScreen';
import BottomNav from './components/BottomNav';
import { NavTab } from './types';

// Wrapper to handle navigation state
const AppContent: React.FC = () => {
  const location = useLocation();
  const navigate = useNavigate();
  
  const getActiveTab = (path: string): NavTab => {
    if (path.includes('chat')) return NavTab.CHAT;
    return NavTab.DAILY;
  };

  const [activeTab, setActiveTab] = useState<NavTab>(getActiveTab(location.pathname));

  const handleTabChange = (tab: NavTab) => {
    setActiveTab(tab);
    if (tab === NavTab.DAILY) navigate('/');
    if (tab === NavTab.CHAT) navigate('/chat');
  };

  return (
    <div className="h-screen w-full bg-gray-50 flex flex-col mx-auto max-w-md shadow-2xl overflow-hidden relative">
      <div className="flex-1 overflow-hidden relative">
        <Routes>
          <Route path="/" element={<QuoteScreen />} />
          <Route path="/chat" element={<ChatScreen />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </div>
      <BottomNav activeTab={activeTab} onTabChange={handleTabChange} />
    </div>
  );
};

const App: React.FC = () => {
  return (
    <Router>
      <div className="min-h-screen bg-gray-100 flex items-center justify-center">
        {/* Container to simulate mobile frame on desktop */}
        <AppContent />
      </div>
    </Router>
  );
};

export default App;