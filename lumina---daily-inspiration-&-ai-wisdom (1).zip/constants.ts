import { Quote } from './types';

export const APP_NAME = "Lumina";

export const QUOTES: Quote[] = [
  { id: 1, text: "The only way to do great work is to love what you do.", author: "Steve Jobs", category: "Work" },
  { id: 2, text: "Believe you can and you're halfway there.", author: "Theodore Roosevelt", category: "Motivation" },
  { id: 3, text: "Act as if what you do makes a difference. It does.", author: "William James", category: "Impact" },
  { id: 4, text: "Success is not final, failure is not fatal: it is the courage to continue that counts.", author: "Winston Churchill", category: "Resilience" },
  { id: 5, text: "What you get by achieving your goals is not as important as what you become by achieving your goals.", author: "Zig Ziglar", category: "Growth" },
  { id: 6, text: "Your time is limited, so don't waste it living someone else's life.", author: "Steve Jobs", category: "Authenticity" },
  { id: 7, text: "The best way to predict the future is to create it.", author: "Peter Drucker", category: "Future" },
  { id: 8, text: "Happiness is not something ready made. It comes from your own actions.", author: "Dalai Lama", category: "Happiness" },
  { id: 9, text: "In the middle of every difficulty lies opportunity.", author: "Albert Einstein", category: "Perspective" },
  { id: 10, text: "Do not let making a living prevent you from making a life.", author: "John Wooden", category: "Balance" },
  { id: 11, text: "Keep your face always toward the sunshine—and shadows will fall behind you.", author: "Walt Whitman", category: "Positivity" },
  { id: 12, text: "It is never too late to be what you might have been.", author: "George Eliot", category: "Possibility" },
  { id: 13, text: "To be yourself in a world that is constantly trying to make you something else is the greatest accomplishment.", author: "Ralph Waldo Emerson", category: "Authenticity" },
  { id: 14, text: "Everything you've ever wanted is on the other side of fear.", author: "George Addair", category: "Courage" },
  { id: 15, text: "Pain is inevitable. Suffering is optional.", author: "Haruki Murakami", category: "Mindfulness" }
];