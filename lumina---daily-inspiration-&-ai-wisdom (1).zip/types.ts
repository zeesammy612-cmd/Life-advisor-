export interface Quote {
  id: number;
  text: string;
  author: string;
  category: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: Date;
  isStreaming?: boolean;
}

export enum NavTab {
  DAILY = 'DAILY',
  CHAT = 'CHAT',
  SETTINGS = 'SETTINGS'
}