import React from 'react';
import { Quote as QuoteIcon, MessageCircle, Settings } from 'lucide-react';
import { NavTab } from '../types';

interface BottomNavProps {
  activeTab: NavTab;
  onTabChange: (tab: NavTab) => void;
}

const BottomNav: React.FC<BottomNavProps> = ({ activeTab, onTabChange }) => {
  const getButtonClass = (tab: NavTab) => {
    const baseClass = "flex flex-col items-center justify-center w-full h-full transition-colors duration-200";
    return activeTab === tab 
      ? `${baseClass} text-indigo-600` 
      : `${baseClass} text-gray-400 hover:text-gray-600`;
  };

  return (
    <div className="fixed bottom-0 left-0 right-0 h-16 bg-white border-t border-gray-200 shadow-lg z-50 pb-safe">
      <div className="flex justify-around items-center h-full max-w-md mx-auto">
        <button 
          onClick={() => onTabChange(NavTab.DAILY)}
          className={getButtonClass(NavTab.DAILY)}
        >
          <QuoteIcon size={24} />
          <span className="text-xs font-medium mt-1">Daily</span>
        </button>
        
        <button 
          onClick={() => onTabChange(NavTab.CHAT)}
          className={getButtonClass(NavTab.CHAT)}
        >
          <MessageCircle size={24} />
          <span className="text-xs font-medium mt-1">Chat</span>
        </button>

        {/* Placeholder for settings or profile */}
        <button 
           onClick={() => {}}
           className="flex flex-col items-center justify-center w-full h-full text-gray-300 cursor-not-allowed"
        >
          <Settings size={24} />
          <span className="text-xs font-medium mt-1">Settings</span>
        </button>
      </div>
    </div>
  );
};

export default BottomNav;