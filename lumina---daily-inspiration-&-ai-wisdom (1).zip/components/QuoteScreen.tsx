import React, { useState, useEffect } from 'react';
import { Share2, RefreshCw, Heart } from 'lucide-react';
import { Quote } from '../types';
import { getDailyQuote, getRandomQuote } from '../services/quoteService';

const QuoteScreen: React.FC = () => {
  const [quote, setQuote] = useState<Quote | null>(null);
  const [isLiked, setIsLiked] = useState(false);
  const [isAnimating, setIsAnimating] = useState(false);

  useEffect(() => {
    // Load initial daily quote
    setQuote(getDailyQuote());
  }, []);

  const handleShuffle = () => {
    setIsAnimating(true);
    setTimeout(() => {
      setQuote(getRandomQuote());
      setIsLiked(false);
      setIsAnimating(false);
    }, 300);
  };

  const handleShare = async () => {
    if (quote && navigator.share) {
      try {
        await navigator.share({
          title: 'Daily Inspiration',
          text: `"${quote.text}" — ${quote.author}`,
        });
      } catch (err) {
        console.log('Share failed', err);
      }
    }
  };

  if (!quote) return <div className="flex items-center justify-center h-screen bg-gray-50">Loading...</div>;

  return (
    <div className="flex flex-col h-full bg-gradient-to-br from-indigo-50 to-purple-50 px-6 pt-12 pb-24 relative overflow-hidden">
      {/* Decorative background elements */}
      <div className="absolute top-[-50px] right-[-50px] w-64 h-64 bg-purple-200 rounded-full mix-blend-multiply filter blur-3xl opacity-30 animate-blob"></div>
      <div className="absolute top-[-50px] left-[-50px] w-64 h-64 bg-indigo-200 rounded-full mix-blend-multiply filter blur-3xl opacity-30 animate-blob animation-delay-2000"></div>
      <div className="absolute bottom-20 left-20 w-64 h-64 bg-pink-200 rounded-full mix-blend-multiply filter blur-3xl opacity-30 animate-blob animation-delay-4000"></div>

      <header className="mb-8 z-10">
        <h1 className="text-3xl font-bold text-gray-800 tracking-tight">Daily<br /><span className="text-indigo-600">Inspiration</span></h1>
        <p className="text-gray-500 mt-2 text-sm">{new Date().toLocaleDateString(undefined, { weekday: 'long', month: 'long', day: 'numeric' })}</p>
      </header>

      <main className="flex-1 flex flex-col justify-center items-center z-10">
        <div 
          className={`glass-panel w-full max-w-md p-8 rounded-3xl shadow-xl transition-all duration-500 transform ${isAnimating ? 'opacity-0 scale-95' : 'opacity-100 scale-100'}`}
        >
          <div className="mb-6">
            <span className="inline-block px-3 py-1 bg-indigo-100 text-indigo-700 text-xs font-semibold rounded-full uppercase tracking-wide">
              {quote.category}
            </span>
          </div>
          
          <blockquote className="font-serif text-2xl md:text-3xl text-gray-800 leading-relaxed mb-6">
            "{quote.text}"
          </blockquote>
          
          <cite className="block text-right not-italic text-gray-600 font-medium text-lg">
            — {quote.author}
          </cite>
        </div>

        <div className="flex gap-6 mt-10">
          <button 
            onClick={() => setIsLiked(!isLiked)}
            className={`p-4 rounded-full shadow-md transition-all duration-200 ${isLiked ? 'bg-red-50 text-red-500' : 'bg-white text-gray-400 hover:text-red-400'}`}
          >
            <Heart size={24} fill={isLiked ? "currentColor" : "none"} />
          </button>
          
          <button 
            onClick={handleShuffle}
            className="p-4 bg-white text-gray-600 rounded-full shadow-md hover:bg-gray-50 active:scale-95 transition-all duration-200"
          >
            <RefreshCw size={24} />
          </button>

          <button 
            onClick={handleShare}
            className="p-4 bg-indigo-600 text-white rounded-full shadow-lg shadow-indigo-200 hover:bg-indigo-700 active:scale-95 transition-all duration-200"
          >
            <Share2 size={24} />
          </button>
        </div>
      </main>
    </div>
  );
};

export default QuoteScreen;